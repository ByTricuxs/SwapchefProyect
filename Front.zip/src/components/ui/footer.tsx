interface footerProps{
    text: string
}

export default function footerProps(){
    return(
        <footer className="bg-[#4E1F00] text-white text-center py-7 text-xs w-full">
      © 2025 SwapChef
    </footer>
    )
}