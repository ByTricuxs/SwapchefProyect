<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\RecetasController;

Route::get('/', function () {
    return view('welcome');
});

Route::prefix('recetas')->group(function () {
    Route::get('/create', [RecetasController::class, 'create'])->name('recetas.create');
    Route::post('/', [RecetasController::class, 'store'])->name('recetas.store');
});