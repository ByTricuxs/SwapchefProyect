

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Register New Product</title>
    <!-- Styles / Scripts -->
        <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php else: ?>
            <style>
            </style>
        <?php endif; ?>
   
</head>
<body class="bg-gray-50">
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white overflow-hidden shadow-lg sm:rounded-lg">
                <div class="p-8 bg-white border-b border-gray-200">
                    <h2 class="text-4xl font-bold mb-8 text-gray-800">Registrar nueva receta</h2>
                    
                    <form method="POST" action="<?php echo e(route('recetas.store')); ?>" enctype="multipart/form-data" class="space-y-6">
                        <?php echo csrf_field(); ?>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="space-y-2">
                                <label for="title" class="block text-sm font-medium text-gray-700">Titulo</label>
                                <input type="text" name="title" id="title" value="<?php echo e(old('title')); ?>" required
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 transition duration-150">
                            </div>
                            <div class="space-y-2">
                                <label for="author" class="block text-sm font-medium text-gray-700">Autor</label>
                                <input type="text" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 transition duration-150" 
                                    id="author" name="author" value="<?php echo e(old('author')); ?>" required>
                                <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600 text-sm" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="space-y-2">
                                <label for="category" class="block text-sm font-medium text-gray-700">Categoria</label>
                                <select class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 transition duration-150" id="category" name="category" required>
                                    <option value="">Select a category</option>
                                    <option value="Postres">Postres</option>
                                    <option value="Desayunos">Desayunos</option>
                                    <option value="Comidas">Comidas</option>
                                    <option value="Reposterias">Reposterias</option>
                                    <option value="Vegetarianos">Vegetarianos</option>    
                                </select>
                                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600 text-sm" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="space-y-2 md:col-span-2">
                                <label for="image" class="block text-sm font-medium text-gray-700">Product Image</label>                                
                                <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md hover:border-indigo-500 transition duration-150">
                                    <div class="space-y-1 text-center">
                                        <div id="imagePreviewContainer" class="hidden mb-4">
                                            <img id="imagePreview" class="mx-auto max-h-48 rounded-lg shadow-lg" alt="Image preview">
                                        </div>
                                        <svg id="uploadIcon" class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                                            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                        <div class="flex text-sm text-gray-600">
                                            <label for="image" class="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500">
                                                <span>Upload a file</span>
                                                <input id="image" name="image" type="file" class="sr-only" accept="image/*" required>
                                            </label>
                                        </div>
                                        <p class="text-xs text-gray-500">PNG, JPG, GIF up to 2MB</p>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600 text-sm" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="space-y-2 md:col-span-2">
                                <label for="ingredients" class="block text-sm font-medium text-gray-700">Ingredientes</label>
                                <textarea class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 transition duration-150" 
                                    id="ingredients" name="ingredients" rows="4" required><?php echo e(old('ingredients')); ?></textarea>
                                <?php $__errorArgs = ['ingredients'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600 text-sm" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>                           
                            
                            <div class="space-y-2 md:col-span-2">
                                <label for="description" class="block text-sm font-medium text-gray-700">Pasos</label>
                                <textarea class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 transition duration-150" 
                                    id="steps" name="steps" rows="4" required><?php echo e(old('steps')); ?></textarea>
                                <?php $__errorArgs = ['steps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-600 text-sm" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            
                            
                        </div>

                        <div class="pt-6">
                            <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150">
                                Register Product
                            </button>
                        </div>
                    </form>
                </div>            
            </div>
        </div>
    </div>    
    
    <script>
        // Wait for the HTML document to be fully loaded before running our code
        document.addEventListener('DOMContentLoaded', function() {
            // Get references to all the HTML elements we need to work with
            const imageInput = document.getElementById('image');           // The file input element
            const imagePreview = document.getElementById('imagePreview');  // The img element that will show the preview
            const imagePreviewContainer = document.getElementById('imagePreviewContainer'); // Container for the preview image
            const uploadIcon = document.getElementById('uploadIcon');      // The upload icon SVG

            // Listen for when the user selects a file using the file input
            imageInput.addEventListener('change', function() {
                // this.files[0] contains the first (and only) file selected
                const file = this.files[0];
                
                if (file) {
                    // Create a FileReader object to read the selected image file
                    const reader = new FileReader();
                    
                    // Set up what should happen when the FileReader finishes loading the file
                    reader.addEventListener('load', function() {
                        // reader.result contains the file's contents as a data URL
                        // Set this as the source of our preview image
                        imagePreview.src = reader.result;
                        
                        // Show the preview container by removing the 'hidden' class
                        imagePreviewContainer.classList.remove('hidden');
                        
                        // Hide the upload icon since we're showing the preview
                        uploadIcon.classList.add('hidden');
                    });
                    
                    // Start reading the file as a data URL (base64 encoded string)
                    reader.readAsDataURL(file);
                } else {
                    // If no file is selected (user canceled the file dialog):
                    // Clear the preview image source
                    imagePreview.src = '';
                    
                    // Hide the preview container
                    imagePreviewContainer.classList.add('hidden');
                    
                    // Show the upload icon again
                    uploadIcon.classList.remove('hidden');
                }
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\swapChef\resources\views/recetas/create.blade.php ENDPATH**/ ?>