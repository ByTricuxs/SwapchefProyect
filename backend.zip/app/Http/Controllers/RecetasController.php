<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Receta; 

class RecetasController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $recetas = Receta::all();
        // compact() is a PHP function that creates an array using variable names
        return view('recetas.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'author' => 'required',
            'category' => 'required',             
            'image' => 'required|image|max:2048',   // Must be an image file, max 2MB
            'ingredients' => 'required|string|max:7000',   
            'steps' => 'required|string|max:7000',               
        ]);

        $imagePath = $request->file('image')->store('recipes', 'public');

        $receta = Receta::create([
            'title' => $request->title,
            'author' => $request->author,
            'category' => $request->category,
            'image' => $imagePath,
            'ingredients' => $request->ingredients,
            'steps' => $request->steps,
        ]);

        return redirect()->route('recetas.create')->with('success');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    //API method

    public function all()
    {
        $recetas = Receta::all();
        return response()->json($recetas);
    }
}
